# Main.ps1 - Application launcher

# Get the directory where this script is located
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

# Set up directory paths
$modulesPath = Join-Path $scriptPath "Modules"
$uiPath = Join-Path $scriptPath "UI"
$dataPath = Join-Path $scriptPath "Data"

# Set execution policy for this session
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force -ErrorAction SilentlyContinue

# Load required assemblies
try {
    Add-Type -AssemblyName PresentationFramework -ErrorAction Stop
    Add-Type -AssemblyName PresentationCore -ErrorAction Stop
    Add-Type -AssemblyName WindowsBase -ErrorAction Stop
}
catch {
    Write-Host "ERROR: Failed to load WPF assemblies: $_" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# IMPORTANT: Load modules in correct dependency order
$modulesToLoad = @(
    # 1. Shared utilities first
    @{Path="Shared\UIControls.ps1"; Required=$true},
    @{Path="Shared\DialogManager.ps1"; Required=$true},
    @{Path="Shared\StatusManager.ps1"; Required=$true},

    # 2. Core models and utilities
    @{Path="Site\Models\SiteEntry.ps1"; Required=$true},
    @{Path="Site\Models\DeviceInfo.ps1"; Required=$true},
    @{Path="Site\Core\ValidationUtils.ps1"; Required=$true},  # ValidationUtility must be loaded before FieldManager
    @{Path="Site\Core\FieldManager.ps1"; Required=$true},
    @{Path="Site\Core\DeviceManager.ps1"; Required=$true},

    # 3. UI Components
    @{Path="Site\UI\FormManager.ps1"; Required=$true},
    @{Path="Site\UI\EditWindow.ps1"; Required=$true},

    # 4. Data handling
    @{Path="Site\Data\ImportExport.ps1"; Required=$false},

    # 5. IP Network components
    @{Path="IP\Models\SubnetEntry.ps1"; Required=$true},
    @{Path="IP\Core\SubnetManager.ps1"; Required=$true},
    @{Path="IP\UI\IPNetworkControls.ps1"; Required=$true}
)

# Load modules
foreach ($module in $modulesToLoad) {
    $modulePath = Join-Path $modulesPath $module.Path
    if (Test-Path $modulePath) {
        try {
            . $modulePath
            Write-Host "Loaded module: $($module.Path)" -ForegroundColor Green
        }
        catch {
            $errorMessage = "Failed to load module $($module.Path): $_"
            if ($module.Required) {
                Write-Host "ERROR: $errorMessage" -ForegroundColor Red
                Read-Host "Press Enter to exit"
                exit 1
            }
            else {
                Write-Host "WARNING: $errorMessage" -ForegroundColor Yellow
            }
        }
    }
    else {
        $errorMessage = "Module not found: $modulePath"
        if ($module.Required) {
            Write-Host "ERROR: $errorMessage" -ForegroundColor Red
            Read-Host "Press Enter to exit"
            exit 1
        }
        else {
            Write-Host "WARNING: $errorMessage" -ForegroundColor Yellow
        }
    }
}

# Load XAML files
$xamlFile = Join-Path $uiPath "NetworkManagement.xaml"
if (-not (Test-Path $xamlFile)) {
    Write-Host "ERROR: Main XAML file not found at $xamlFile" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

try {
    # Load and parse XAML
    $xaml = Get-Content $xamlFile -Raw
    $xml = [xml]$xaml
    
    # Create the window
    $reader = New-Object System.Xml.XmlNodeReader $xml
    
    # Add the phone formatter resource
    $phoneConverter = [PhoneNumberConverter]::new()
    $resourceDict = New-Object System.Windows.ResourceDictionary
    $resourceDict.Add("PhoneFormatter", $phoneConverter)
    
    # Load the window with resources
    $mainWin = [Windows.Markup.XamlReader]::Load($reader)
    $mainWin.Resources = $resourceDict
    
    # Initialize managers
    $script:DeviceManager = [DevicePanelManager]::new($mainWin)
    $script:FieldManager = [FieldMappingManager]::new($mainWin)
    
    # Show the window
    $mainWin.ShowDialog()
}
catch {
    Write-Host "ERROR: Failed to start application: $_" -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkRed
    Read-Host "Press Enter to exit"
    exit 1
}
finally {
    # Cleanup
    if ($reader) { $reader.Close() }
}